#!/usr/bin/env python3

import unittest

from test.test_transduce import TestTransduce
from test.test_transduce import TestTheUtils

if __name__ == "__main__":
    unittest.main()
